﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.IO;
public partial class book : System.Web.UI.Page
{
    
    string bname, price, id, cat, img;
    SqlConnection con;
    SqlCommand cmd, cmd1, cmd2;
    SqlDataReader dr, dr1;
    SqlDataAdapter da;
    //List<string> objList;
    protected void Page_Load(object sender, EventArgs e)
    {
        string s = ConfigurationManager.ConnectionStrings["bookcon"].ConnectionString;
        con = new SqlConnection(s);
        //objList = new List<string>();
    }

    protected void GridView2_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        con.Open();
        int rowIndex = Convert.ToInt32(e.CommandArgument);
            string n = GridView2.Rows[rowIndex].Cells[0].Text;
         //   string s = GridView2.Rows[rowIndex].Cells[4].Text;
            int ID = Convert.ToInt32(n);
            //Response.Write(s);
            //int index = rowIndex + 1;
            cmd = new SqlCommand();
            
            //int index = Convert.ToInt32(e.CommandArgument.ToString() + 1);
            cmd.CommandText = "select * from BOOKS where bid=@t1";
            cmd.Parameters.Add("t1", ID);
            cmd.Connection = con;
            cmd.CommandType = CommandType.Text;
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                id=dr.GetValue(0).ToString();
                ViewState["id"] = id;
                bname = dr.GetValue(1).ToString();
                price = dr.GetValue(2).ToString();
                cat = dr.GetValue(4).ToString();
                img=dr.GetValue(3).ToString();
                if (Session["user"] != null)
                {
                    dr.Close();   
                    string uname = Session["user"].ToString();
                    cmd2 = new SqlCommand();
                    cmd2.CommandText = "select * from cart where cid=@t2 and username=@t3";
                    cmd2.Parameters.Add("t2", id);
                    cmd2.Parameters.Add("t3", uname);
                    cmd2.Connection = con;
                    cmd2.CommandType = CommandType.Text;
                    dr1 = cmd2.ExecuteReader();
                    if (dr1.HasRows)
                    {
                        Label1.Visible = true;
                        Label1.Text = "Alreday enteredd";
                    }
                    else
                    {
                        dr1.Close();
                        cmd1 = new SqlCommand();
                        cmd1.CommandText = "insert into cart(cid,cname,category, price, image, username) values('" + id + "', '" + bname + "', '" + cat + "', '" + price + "', '" + img + "', '" + uname + "')";
                        cmd1.Connection = con;
                        cmd1.CommandType = CommandType.Text;
                        cmd1.ExecuteNonQuery();
                    }
                    
                }
                else
                {
                    Response.Redirect("customerLogin.aspx");   
                }
            }

            TextBox1.Visible = true;
            Button1.Visible = true;
           
          
    }
   
    protected void Button1_Click(object sender, EventArgs e)
    {
        con.Open();
        int quantity;
        /*if (TextBox1.Text != null)
        {
             quantity = Convert.ToInt32(TextBox1.Text);   
        }
        else
        {
             quantity = 1;
        }*/
        //Response.Write(id);
        quantity = Convert.ToInt32(TextBox1.Text); 
        int i = Convert.ToInt32(ViewState["id"]);
        cmd = new SqlCommand();
        cmd.CommandText = "update cart set quantity= " + quantity + " where cid=" + i;
        cmd.Connection = con;
        cmd.CommandType = CommandType.Text;
        cmd.ExecuteNonQuery();
        Response.Redirect("cart.aspx");
    }
}
    

   