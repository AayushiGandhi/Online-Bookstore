﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class category : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd, cmd1;
    SqlDataReader dr;
    SqlDataAdapter da;
    protected void Page_Load(object sender, EventArgs e)
    {
        //Response.Write(Session["cart"].ToString());
        string s = ConfigurationManager.ConnectionStrings["bookcon"].ConnectionString;
        con = new SqlConnection(s);
        con.Open();
        cmd = new SqlCommand();
        cmd.CommandText = "select * from BOOKS where category=@t1";
        cmd.Connection = con;
        cmd.CommandType = CommandType.Text;
        
        string s1 = Session["cart"].ToString();
        cmd.Parameters.Add("t1", s1);
        dr = cmd.ExecuteReader();
        //Label1.Text = Session["cart"].ToString();
        if (dr.HasRows)
        {
            GridView1.Visible = true;
           // GridView1.DataSource = dr;
          //  GridView1.DataBind();
        }
        else
        {
            GridView1.Visible = false;
            Label1.Visible = true;
            Label1.Text = "Nothing to display";
        }
   
    }
}