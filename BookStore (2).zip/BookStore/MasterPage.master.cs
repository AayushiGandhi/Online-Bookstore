﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
public partial class MasterPage : System.Web.UI.MasterPage
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataReader dr;
    SqlDataAdapter da;
    protected void Page_Load(object sender, EventArgs e)
    {
        string s = ConfigurationManager.ConnectionStrings["bookcon"].ConnectionString;
        con = new SqlConnection(s);
    }
    protected void Menu1_MenuItemClick(object sender, MenuEventArgs e)
    {

    }
    protected void login_Click(object sender, EventArgs e)
    {
        //Session["user"] = null;
        Response.Redirect("login.aspx");
    }
    protected void signup_Click(object sender, EventArgs e)
    {
        //Session["user"] = null;
        Response.Redirect("signup.aspx");
    }
    protected void logout_Click(object sender, EventArgs e)
    {
        Session["user"] = null;
        Response.Redirect("home.aspx");
        
    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        Session["books"] = search.Text.ToString();
        Response.Redirect("search.aspx");
    }
    protected void artsandcraft_Click(object sender, EventArgs e)
    {
        Session["cart"] = "Arts & Craft";
        Response.Redirect("category.aspx");
    }
    protected void bodymindandspirit_Click(object sender, EventArgs e)
    {
        Session["cart"] = "Body, Mind and Spirit";
        Response.Redirect("category.aspx");
    }
    protected void cn_Click(object sender, EventArgs e)
    {
        Session["cart"] = "Computer Network";
        Response.Redirect("category.aspx");
    }
    protected void env_Click(object sender, EventArgs e)
    {
        Session["cart"] = "Environment";
        Response.Redirect("category.aspx");
    }
    protected void fiction_Click(object sender, EventArgs e)
    {
        Session["cart"] = "Fiction";
        Response.Redirect("category.aspx");
    }
    protected void science_Click(object sender, EventArgs e)
    {
        Session["cart"] = "Science and Engineering";
        Response.Redirect("category.aspx");
    }
    protected void food_Click(object sender, EventArgs e)
    {
        Session["cart"] = "Cookery and Food";
        Response.Redirect("category.aspx");
    }
}
