﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class customerLogin : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataReader dr;
    SqlDataAdapter da;
    protected void Page_Load(object sender, EventArgs e)
    {
        string s = ConfigurationManager.ConnectionStrings["bookcon"].ConnectionString;
        con = new SqlConnection(s);
    }
    protected void submit_Click(object sender, EventArgs e)
    {
        con.Open();
        cmd = new SqlCommand();
        cmd.CommandText = "select * from Customer where Email=@t1 and Password=@t2";
        cmd.Parameters.Add("t1", email.Text);
        cmd.Parameters.Add("t2", password.Text);
        cmd.Connection = con;
        cmd.CommandType = CommandType.Text;
        dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {
            if (dr.Read())
            {
                Label1.Text = "Sucess";

                Session["user"] = dr.GetValue(0).ToString();
                //Response.Write(Session["user"]);
                Response.Redirect("home.aspx");
            }
        }
        else
            Label1.Text = "Invalid";
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("forgotpassword.aspx");
    }
}