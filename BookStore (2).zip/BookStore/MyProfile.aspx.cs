﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


public partial class MyProfile : System.Web.UI.Page
{

    SqlConnection con;
    SqlCommand cmd;
    SqlDataReader dr;
    SqlDataAdapter da;
    protected void Page_Load(object sender, EventArgs e)
    {
        string s = ConfigurationManager.ConnectionStrings["bookcon"].ConnectionString;
        con = new SqlConnection(s);
        con.Open();
        cmd = new SqlCommand();
        cmd.CommandText = "select * from Customer where Name=@t1";
        string email = Session["user"].ToString();
        cmd.Parameters.Add("t1", email);
        cmd.Connection = con;
        cmd.CommandType = CommandType.Text;
        dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {
            while (dr.Read())
            {
                Label2.Text = dr.GetValue(0).ToString();
                Label3.Text = dr.GetValue(1).ToString();
                Label4.Text = dr.GetValue(2).ToString();
                Label5.Text = dr.GetValue(3).ToString();
                Label6.Text = dr.GetValue(4).ToString();
            }
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("UpdateProfile.aspx");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("home.aspx");
    }
}