﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
public partial class forgotpassword : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd,cmd1;
    SqlDataReader dr;
    protected void Page_Load(object sender, EventArgs e)
    {
        string s = ConfigurationManager.ConnectionStrings["bookcon"].ConnectionString;
        con = new SqlConnection(s);
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        con.Open();
        string email = TextBox1.Text;
        cmd1 = new SqlCommand();
        cmd1.CommandText = "select * from Customer where Email=@t3";
        cmd1.Parameters.Add("t3", email);
        cmd1.CommandType = CommandType.Text;
        cmd1.Connection = con;
        dr = cmd1.ExecuteReader();
        if (dr.HasRows)
        {
            dr.Close();
            cmd = new SqlCommand();
            cmd.CommandText = "update Customer set Password=@t1 where Email=@t2";
            cmd.Parameters.Add("t1", TextBox2.Text);
            cmd.Parameters.Add("t2", email);
            cmd.Connection = con;
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            Response.Redirect("customerLogin.aspx");
        }
        else
        {
            Label2.Visible = true; 
            
            Label2.Text = "Invalid Email Address";
        }
    }
}