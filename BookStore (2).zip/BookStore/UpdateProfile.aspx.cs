﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class UpdateProfile : System.Web.UI.Page
{
    
    SqlConnection con;
    SqlCommand cmd, cmd1;
    SqlDataReader dr;
    SqlDataAdapter da;
    protected void Page_Load(object sender, EventArgs e)
    {
        string s = ConfigurationManager.ConnectionStrings["bookcon"].ConnectionString;
        con = new SqlConnection(s);
        con.Open();
        cmd = new SqlCommand();
        cmd.CommandText = "select * from Customer where Name=@t1";
        string name = Session["user"].ToString();
        cmd.Parameters.Add("t1", name);
        cmd.Connection = con;
        cmd.CommandType = CommandType.Text;
        dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {
            while (dr.Read())
            {
                TextBox1.Text = dr.GetValue(0).ToString();
                TextBox2.Text = dr.GetValue(1).ToString();
                TextBox3.Text = dr.GetValue(2).ToString();
                TextBox4.Text = dr.GetValue(3).ToString();
                TextBox5.Text = dr.GetValue(4).ToString();
            }
            dr.Close();
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string name = Session["user"].ToString();
        cmd1 = new SqlCommand();
        cmd1.CommandText = "update Customer set Name='" + TextBox1.Text + "', Email='" + TextBox2.Text + "', Password='" + TextBox3.Text + "', Mobile='" + TextBox4.Text + "' ,Address='" + TextBox5.Text + "' where Name=@t1";
        cmd1.Parameters.Add("t1", name);
        cmd1.CommandType = CommandType.Text;
        cmd1.Connection = con;
        cmd1.ExecuteNonQuery();
       // Response.Redirect("MyProfile.aspx");
    }
}