﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
public partial class _Default : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd, cmd1;
    SqlDataReader dr;
    SqlDataAdapter da;
    DataTable dt=new DataTable();
    //DataRow dr;
    protected void Page_Load(object sender, EventArgs e)
    {
        //Response.Write(Request.QueryString["name"].ToString());
        string s = ConfigurationManager.ConnectionStrings["bookcon"].ConnectionString;
        con = new SqlConnection(s);
        con.Open();
        if (Session["user"] != null)
        {
            string uname = Session["user"].ToString();
            string cmdText = "SELECT * FROM cart where username='" + uname + "'";
           // Response.Write(Session["user"].ToString());
            da = new SqlDataAdapter(cmdText, con);
            
            DataSet ds = new DataSet();
            da.Fill(ds);
            double totalSalary = 0;
            int quantity;
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                quantity = Convert.ToInt32(dr["quantity"]);
                
                totalSalary += Convert.ToDouble(dr["price"]) * quantity;
            }
            GridView1.Columns[2].FooterText = "Grand Total";
            //--- Here 3 is the number of column where you want to show the total.  
            GridView1.Columns[3].FooterText = totalSalary.ToString();
            ///dr = cmd.ExecuteReader();*/
        }
        else
        {
            Response.Redirect("customerLogin.aspx");
        }
    }
    

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        //con.Open();
        int rowIndex = Convert.ToInt32(e.CommandArgument);
        string n = GridView1.Rows[rowIndex].Cells[0].Text;
        int ID = Convert.ToInt32(n);
        cmd = new SqlCommand();
        cmd.CommandText = "delete from cart where cid=@t1";
        cmd.Parameters.Add("t1", ID);
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        cmd.ExecuteNonQuery();
        Response.Redirect("cart.aspx");
    }
}