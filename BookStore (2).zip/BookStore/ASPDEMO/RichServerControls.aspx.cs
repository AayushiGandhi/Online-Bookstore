﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class RichServerControls : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            MultiView1.ActiveViewIndex = 0;
        }

    }
    protected void btnStep2_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex++;

    }
    protected void btnBackToStep2_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex--;

    }
    protected void btnBackToStep1_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex--;

    }
    protected void btnGoToStep3_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex++;
        lblProductID.Text = txtProductID.Text;
        lblProductName.Text = txtProductName.Text;
        lblPrice.Text = txtProductPrice.Text;
        lblOrderID.Text = txtOrderID.Text;
        lblQuantity.Text = txtQuantity.Text;
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {

    }
}