﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CalendarDemo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SelectedDatesCollection c=Calendar1.SelectedDates;
        for (int i = 0; i < c.Count; i++)
        {
            Response.Write("<br>"+c[i].ToShortDateString());
        }
    }
    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {
        Response.Write("<br>" + Calendar1.SelectedDate.ToLongDateString() );
    }
}