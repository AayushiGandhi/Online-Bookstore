﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack==false)
        {
            Response.Write("<br>First time");
        }
        else
        {
            Response.Write("<br>Next..........");
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Write("<b> <br>From button click");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("RequestQueryStringDemo.aspx?name=" + txtName.Text);
    }
}