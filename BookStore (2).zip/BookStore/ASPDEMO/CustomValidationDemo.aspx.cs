﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default4 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label1.Text = "You entered "+TextBox1.Text;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {

    }
    protected void Button1_Click1(object sender, EventArgs e)
    {

    }
    protected void CustomValidator2_ServerValidate(object source, ServerValidateEventArgs args)
    {
        /*
            Password must be between 6-12 characters.
            Must have one capital letter.
            Must have one lowercase letter.
            Must have one numeric value.
         */
        string inputData = args.Value;        
          args.IsValid = false;        
          if (inputData.Length < 6 || inputData.Length > 12) return;       
          bool upperCase = false;
          foreach (char ch in inputData)
          {
                if (ch >= 'A' && ch <= 'Z')
                {
                       upperCase = true; 
                       break;
                }
           }
           if (!upperCase) return;       
           bool lowerCase = false;
           foreach (char ch in inputData)
           {
                  if (ch >= 'a' && ch <= 'z')
                  {
                         lowerCase = true; break;
                   }
            }
            if (!lowerCase) return;      
            bool number = false;
            foreach (char ch in inputData)
           {
                 if (ch >= '0' && ch <= '9')
                 {
                        number = true; break;
                 }
            }
            if (!number) return;        
            args.IsValid = true;
       }

    
}