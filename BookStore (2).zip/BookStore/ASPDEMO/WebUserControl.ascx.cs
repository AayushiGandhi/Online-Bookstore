﻿using System;
using System.Drawing;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class WebUserControl : System.Web.UI.UserControl
{
    protected Color backColor;
    public Color BackColor
    {
        get
        {
            return backColor;
        }
        set
        {
            backColor = value;
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        Panel1.BackColor = backColor;
    }
}