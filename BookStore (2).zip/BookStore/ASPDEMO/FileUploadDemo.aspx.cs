﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class FileUploadDemo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (FileUpload1.HasFile)
        { 
            try
            {
                Response.Write(" Uploaded file:" + FileUpload1.FileName);
                //save the file
                string filename = FileUpload1.FileName;
                FileUpload1.SaveAs(Server.MapPath("~/") + filename); 

                //Showing the file information
                Response.Write("<br/> File Name: " + FileUpload1.PostedFile.FileName);
                Response.Write("<br/> File type: "+ FileUpload1.PostedFile.ContentType);               
                Response.Write("<br/> File length: " + FileUpload1.FileBytes.Length);  
            }
            catch (Exception ex)
            {
                Response.Write("<br/> Error <br/>");
                Response.Write(ex.Message);
            }
       }
        else
        {
            Response.Write("No file uploaded");
        }
    }
}