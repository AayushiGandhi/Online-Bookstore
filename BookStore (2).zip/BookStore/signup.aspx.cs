﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class signup : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd,cmd1;
    SqlDataReader dr;
    SqlDataAdapter da;
    protected void Page_Load(object sender, EventArgs e)
    {
        string s = ConfigurationManager.ConnectionStrings["bookcon"].ConnectionString;
        con = new SqlConnection(s);
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        con.Open();
        cmd = new SqlCommand();
        cmd.CommandText = "insert into Customer values('" + TextBox1.Text + "', '" + TextBox2.Text + "', '" + TextBox3.Text + "', '" + TextBox4.Text + "', '" + TextBox5.Text + "')";
        cmd.Connection = con;
        cmd.CommandType = CommandType.Text;
        cmd1 = new SqlCommand();
        cmd1.CommandText = "select Email from Customer where Email=@t1";
        cmd1.Parameters.AddWithValue("t1", TextBox2.Text);
        cmd1.Connection = con;
        cmd1.CommandType = CommandType.Text;
        SqlDataReader dr = cmd1.ExecuteReader();
        if (dr.HasRows)
        {
            Label1.Text = "User already exists";
        }
        else
        {
            dr.Close();
            cmd.ExecuteNonQuery();
            Label1.Text = "Successsfully Registered...";
        }
        //Response.Redirect("login.aspx");
    }
}