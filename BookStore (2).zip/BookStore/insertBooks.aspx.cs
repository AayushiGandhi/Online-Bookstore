﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
public partial class insertBooks : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataReader dr;
    SqlDataAdapter da;

    protected void Page_Load(object sender, EventArgs e)
    {
                //con.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=E:\WebSite2\App_Data\BookStore.mdf;Integrated Security=True;User Instance=True";
        string s = ConfigurationManager.ConnectionStrings["bookcon"].ConnectionString;
        con = new SqlConnection(s);

    }
    protected void upload_Click(object sender, EventArgs e)
    {
        con.Open();
        cmd = new SqlCommand();
        string cat=category.SelectedItem.ToString();
        string image = FileUpload1.FileName;
        //Label1.Text = image;
        if (FileUpload1.HasFile)
        {
           // string fileExtension = System.IO.Path.GetExtension(FileUpload1.FileName);
            FileUpload1.SaveAs(Server.MapPath("~/") + FileUpload1.FileName);
            //Label1.Text = "";
        cmd.CommandText="insert into BOOKS(bname, price, image, category) values('" + title.Text + "', '" + price.Text + "', '" + image + "', '" +cat +"')";
        cmd.CommandType=CommandType.Text;
        cmd.Connection=con;
        cmd.ExecuteNonQuery();
        }
        else
        {
            Label1.Text="Please select a photo";
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("viewdata.aspx");
    }
}